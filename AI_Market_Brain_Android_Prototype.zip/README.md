# AI Market Brain — Android Prototype

This is a build-ready Android Studio prototype for the AI Market Brain concept.

Current version:
- Stocks + Forex watchlist UI
- AI-style signal cards
- Confidence and risk display
- Scanner button (prototype)
- No live market data yet
- No broker integration
- No real-money trading

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build APK(s)

The APK will normally appear under:
app/build/outputs/apk/debug/app-debug.apk

For the next version, connect a reliable market-data API and implement the tested signal/backtesting engine.
