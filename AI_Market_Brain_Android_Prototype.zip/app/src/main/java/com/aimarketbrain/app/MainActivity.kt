package com.aimarketbrain.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Signal(
    val symbol: String,
    val market: String,
    val direction: String,
    val confidence: Int,
    val risk: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MarketBrainApp() }
    }
}

@Composable
fun MarketBrainApp() {
    val signals = listOf(
        Signal("EUR/USD", "Forex", "BULLISH", 76, "Medium"),
        Signal("XAU/USD", "Forex", "BULLISH", 72, "Medium"),
        Signal("AAPL", "Stock", "WAIT", 64, "Low"),
        Signal("NVDA", "Stock", "BEARISH", 69, "Medium")
    )

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("AI Market Brain") })
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Market Scanner", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(4.dp))
                    Text("Prototype • Live data/API connection not yet enabled.")
                }

                item {
                    Button(
                        onClick = { },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("SCAN MARKET")
                    }
                }

                items(signals) { signal ->
                    SignalCard(signal)
                }

                item {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text(
                        "Risk notice: Signals are experimental scenarios, not guaranteed predictions or financial advice.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
fun SignalCard(signal: Signal) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("${signal.symbol} • ${signal.market}",
                style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text("AI Outlook: ${signal.direction}")
            Text("Confidence: ${signal.confidence}%")
            Text("Risk: ${signal.risk}")
            Spacer(Modifier.height(8.dp))
            Text("Entry / SL / TP will be calculated after live-data and strategy engines are connected.")
        }
    }
}
